# nook-bot

The Node.js library for Nook bots.

    npm install https://YOUR-SITE/sdk/nook-bot.tgz

    import { NookBot } from 'nook-bot'
    const bot = new NookBot()   // NOOK_KEY from the environment or a .env file
    bot.command('ping', (m) => m.reply('pong!'))
    bot.start()

Guide: https://YOUR-SITE/developers
